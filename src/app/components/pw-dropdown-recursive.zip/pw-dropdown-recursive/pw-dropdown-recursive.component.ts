import { Component, Input } from '@angular/core';

/**
 * Example of the dropdown items
 * 
  {
    label: "Hello",
    options: [
      'Option 1',
      'Option 2',
      {
        label: 'Option 3',
        options: [
          'Option A',
          'Option B',
        ]
      }
    ]
  };

 */

export interface Option {
  item: string;
  link: string;
}

export interface DropdownItem {
  label: string;
  options: (Option | DropdownItem)[]
}

@Component({
  selector: 'pw-dropdown-recursive',
  templateUrl: './pw-dropdown-recursive.component.html',
  styleUrls: ['./pw-dropdown-recursive.component.scss']
})
export class PwDropdownComponent {
  @Input() items: DropdownItem = {
    label: '',
    options: [{
      item: 'Item default',
      link: ''
    }]
  };
  isOpen = false;

  toggleDropdown() {
    this.isOpen = !this.isOpen;
  }

  isItem(value: any) {
    return value.item !== undefined && value.link !== undefined;
  }

  isDropdown(value:any) {
    return value.options !== undefined;
  }

  asOption(val: any): Option { 
    return val; 
  }

  asDropdownItem(val: any): DropdownItem { 
    return val; 
  }
}
